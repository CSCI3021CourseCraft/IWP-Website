# IWP-Website - CourseCraft - (Milestone 1)

Team: Anna Zagrai, Abimael Lozano.

Course: CSCI 3021, Fall 2026.

Repository: github.com/CSCI3021CourseCraft/IWP-Website

## Stack
- **Server:** Apache Tomcat **10.1** (Jakarta Servlet 6, `jakarta.servlet.*`), built with Maven. Java 17 or newer (tested bytecode level 17; runs on 17, 21, 25).
- **Database:** Supabase (hosted PostgreSQL) through JDBC (`org.postgresql.Driver`, 42.7.4). Hosted, so both teammates share one database.
- **Passwords:** bcrypt (jBCrypt).
- **LLM:** Groq (OpenAI-compatible chat API with tool calling) through `java.net.http.HttpClient`.

> **Tomcat 9?** This project uses `jakarta.*`, so it will NOT deploy on Tomcat 9 (which uses `javax.*`). Either run it on Tomcat 10.1
> (in NetBeans: Tools > Servers > Add Server > Apache Tomcat, point it at a Tomcat 10.1 folder), or, to stay on Tomcat 9,
> replace `jakarta.servlet` with `javax.servlet` in all `.java` files and change the pom dependency to
> `javax.servlet:javax.servlet-api:4.0.1`. Nothing else changes.

## Database
- **Script:** `sql/coursecraft_postgres.sql` creates and fills every table. Paste it into the Supabase SQL Editor and run it. It can be re-run (it drops and rebuilds the tables).
- **Tables and relationships**

| Table | Purpose | Relationships |
|---|---|---|
| users | student accounts (bcrypt password hash) | has many courses and log rows |
| courses | a student's courses | FK user_id -> users |
| canvas_items | assignments, modules, quizzes, files | FK course_id -> courses |
| quiz_results | per-topic quiz scores | FK item_id -> canvas_items |
| notes | student notes | FK course_id -> courses |
| study_plans | plans saved by the student or the agent | FK course_id -> courses |
| agent_log | one row per agent tool call: log_id, user_id, tool_name, input, output, success, created_at | FK user_id -> users |

All foreign keys use ON DELETE CASCADE. There is an index on every foreign key and on `agent_log(user_id, created_at)`. Row level security is enabled on every table so Supabase's public web API cannot read them. The servlets use JDBC.

## How to run
1. Create a Supabase project, open the SQL Editor and run `sql/coursecraft_postgres.sql`.
2. Set these environment variables (Windows: Start > "Edit environment variables for your account"), then restart your IDE so Tomcat inherits them:

| Variable | Value |
|---|---|
| `DB_URL` | `jdbc:postgresql://<session-pooler-host>:5432/postgres?sslmode=require` |
| `DB_USER` | `postgres.<project-ref>` |
| `DB_PASSWORD` | the database password (read only from this variable) |
| `LLM_API_KEY` | the Groq API key (read only from this variable; `GROQ_API_KEY` also works) |
| `LLM_MODEL` | optional, default `llama-3.3-70b-versatile` |
| `AGENT_MAX_STEPS` | optional, default `1` (one plan-act-observe cycle). Up to `8` lets the agent chain tools. |

   - **Host:** `<fill in: aws-N-REGION.pooler.supabase.com>` (Supabase > Connect > Session pooler), **port** 5432, **database** `postgres`.
   - Nothing secret is in the repository or the zip. `src/main/resources/config.properties` (copy of `config.properties.example`) is an optional alternative to environment variables and is listed in `.gitignore`. If a key is in both, the file wins.
3. `cd CourseCraft_endpoints && mvn clean package`, then run on Tomcat 10.1 (from the IDE, or copy `target/CourseCraft.war` into Tomcat's `webapps`).
4. Open `http://localhost:8080/CourseCraft/` (from NetBeans the context path is empty, so use `http://localhost:8080/`). Check the connection at `/dbtest`, then log in as `demo@coursecraft.test` or `example@coursecraft.test` with password `demo1234`.

## Servlets and tools

| Servlet | URL | Method | Agent tool |
|---|---|---|---|
| LoginServlet | /login | POST | (creates the session) |
| LogoutServlet | /logout | GET | |
| CoursesServlet | /api/courses | GET | |
| NotesToolServlet | /api/tools/get_course_notes | GET | get_course_notes |
| MaterialsToolServlet | /api/tools/get_course_materials | GET | get_course_materials |
| QuizResultsToolServlet | /api/tools/get_quiz_results | GET | get_quiz_results |
| SavePlanToolServlet | /api/tools/save_study_plan | POST | save_study_plan (changes data) |
| AgentServlet | /api/agent | POST (`goal`, optional `course_id`) | plan-act-observe cycle(s) |
| DbTestServlet | /dbtest | GET | Connection check (delete before the final project) |

Every tool endpoint checks the session (401 if not logged in), validates its input (400), checks that the course belongs to the logged in student (403), uses `PreparedStatement`, closes its connection in `finally`, and returns JSON with `success` or `error`.

**Agent round trip:** `AgentServlet` sends the goal, the student's real course ids and the four tool definitions to Groq. It runs the tool the model chooses through the same `ToolService` code the endpoints use (as the logged in student: the user id comes from the session, never from the model), writes the call and its result to `agent_log` (also when the tool fails), and returns every step to the page. With `AGENT_MAX_STEPS=1` that is exactly one tool call. A tool error (for example the model asks for another student's course) is returned as a normal observation, not a crash.

Code map: `coursecraft.web` (servlets), `coursecraft.service.ToolService` (all tool logic + agent log), `coursecraft.llm` (Groq client + tool definitions), `coursecraft.util` (config + DB).

## Who built what
- **Anna:** (write one paragraph)
- **Abimael:** (write one paragraph)

## AI tools used
(State which AI tools helped write code)
