# CourseCraft - Milestone 1 (Backend, Database, Agent Foundation)

Team: Anna Zagrai, Abimael Lozano - CSCI 3021, Fall 2026

## Database and tool choice
- **Database:** PostgreSQL on Supabase, accessed with JDBC (PostgreSQL JDBC driver 42.7.3, added in `pom.xml`).
- **Server:** Apache Tomcat 10.1 (Jakarta Servlet 6), Java 25 LTS, built with Maven.
- **LLM:** Anthropic Claude API with tool calling, called via `java.net.http.HttpClient`.

### Schema (`sql/coursecraft_postgres.sql`)
| Table | Purpose | Key relationships |
|---|---|---|
| `users` | accounts (PBKDF2 password hash) | - |
| `courses` | a user's courses | `user_id` -> `users.id` |
| `notes` | notes per course | `course_id` -> `courses.id` |
| `canvas_items` | assignments / modules / quizzes / files | `course_id` -> `courses.id` |
| `quiz_results` | per-topic quiz scores | `item_id` -> `canvas_items.id` |
| `study_plans` | plans saved by the agent | `course_id` -> `courses.id` |
| **`agent_log`** | one row per tool call | `user_id` -> `users.id`; columns `log_id, user_id, tool_name, input, output, success, created_at`; index on `(user_id, created_at)` |

All foreign keys use `ON DELETE CASCADE`; every FK column is indexed.

## How to run
1. In Supabase: SQL Editor -> paste `sql/coursecraft_postgres.sql` -> Run.
2. Create `src/main/resources/config.properties` from `config.properties.example` **or** set environment variables:

| Setting | Where it is read from | Default |
|---|---|---|
| `DB_URL` | env var or config.properties | `jdbc:postgresql://localhost:5432/postgres` |
| `DB_USER` | env var or config.properties | `postgres` |
| `DB_PASSWORD` | env var or config.properties | empty |
| `ANTHROPIC_API_KEY` | env var or config.properties | **required for /api/agent** |
| `ANTHROPIC_MODEL` | env var or config.properties | `claude-haiku-5-5` |
| `AGENT_MAX_STEPS` | env var or config.properties | `1` (one plan-act-observe cycle; up to 8 for the bonus loop) |

   `config.properties` is in `.gitignore`. **No key or password is committed.**
3. `mvn clean package`, then deploy `target/coursecraft.war` to Tomcat 10.1 (or run from the IDE).
4. Open `http://localhost:8080/coursecraft/`. Demo login: `demo@coursecraft.test` / `password123`.

## Servlets
| Servlet | URL | Method | Agent tool |
|---|---|---|---|
| AuthServlet | `/api/auth` | GET, POST (`action=login/register/logout`) | - |
| CourseServlet | `/api/courses` | GET, POST | - |
| NoteServlet | `/api/notes` | POST | - |
| CourseNotesServlet | `/api/tools/course-notes?course_id=` | GET | `get_course_notes` |
| QuizResultsServlet | `/api/tools/quiz-results?course_id=` | GET | `get_quiz_results` |
| SaveStudyPlanServlet | `/api/tools/save-study-plan` | POST (changes state) | `save_study_plan` |
| AgentServlet | `/api/agent` | POST (`goal`, `course_id`) | calls the three tools above |

Every tool endpoint checks the session (401 if not logged in), validates inputs, verifies the user owns the course
(404 otherwise), uses `PreparedStatement`, closes resources in `finally`, and returns JSON with `success` / `error`.
All tool calls (from the agent or directly) go through `ToolService.execute`, which writes `agent_log`.

## Team contributions
- **Anna Zagrai:** Build the SQL backend and integrated the AI agent (Groq)
- **Abimael Lozano:** Wrote the read me and did the basic website building

## AI tools used

## Screen recording / screenshots
See `demo/` (log in -> pick course -> run agent -> show `agent_log` rows in MySQL).
