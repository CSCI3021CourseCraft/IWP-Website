-- CourseCraft schema + sample data (MySQL 8, InnoDB)
-- Run:  mysql -u root -p < sql/coursecraft.sql
DROP DATABASE IF EXISTS coursecraft;
CREATE DATABASE coursecraft CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE coursecraft;

CREATE TABLE users (
  id            BIGINT AUTO_INCREMENT PRIMARY KEY,
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE courses (
  id               BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id          BIGINT NOT NULL,
  canvas_course_id VARCHAR(50) NULL,
  name             VARCHAR(200) NOT NULL,
  INDEX idx_courses_user (user_id),
  CONSTRAINT fk_courses_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE notes (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  course_id  BIGINT NOT NULL,
  title      VARCHAR(200) NOT NULL,
  body       TEXT NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_notes_course (course_id),
  CONSTRAINT fk_notes_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE canvas_items (
  id        BIGINT AUTO_INCREMENT PRIMARY KEY,
  course_id BIGINT NOT NULL,
  type      ENUM('assignment','module','quiz','file') NOT NULL,
  title     VARCHAR(200) NOT NULL,
  due_date  DATE NULL,
  body      TEXT NULL,
  INDEX idx_items_course (course_id, type),
  CONSTRAINT fk_items_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE quiz_results (
  id        BIGINT AUTO_INCREMENT PRIMARY KEY,
  item_id   BIGINT NOT NULL,
  topic     VARCHAR(200) NOT NULL,
  score     DECIMAL(6,2) NOT NULL,
  max_score DECIMAL(6,2) NOT NULL,
  INDEX idx_quiz_item (item_id),
  CONSTRAINT fk_quiz_item FOREIGN KEY (item_id) REFERENCES canvas_items(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE study_plans (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  course_id  BIGINT NOT NULL,
  plan_text  TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_plans_course (course_id, created_at),
  CONSTRAINT fk_plans_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Agent log: one row per tool call (agent or direct REST call)
CREATE TABLE agent_log (
  log_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id    BIGINT NOT NULL,
  tool_name  VARCHAR(100) NOT NULL,
  `input`    TEXT NOT NULL,
  `output`   MEDIUMTEXT NOT NULL,
  success    BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_log_user_time (user_id, created_at),
  CONSTRAINT fk_log_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Sample data ----------
-- Demo login: demo@coursecraft.test / password123  (PBKDF2-HMAC-SHA256)
INSERT INTO users (email, password_hash) VALUES
 ('demo@coursecraft.test',
  '65536:a1b2c3d4e5f60718293a4b5c6d7e8f90:77b886bfe0e05c6ba825e499b689629a4a9acff5ad7d75f873a0114a203fd5d9');

INSERT INTO courses (user_id, canvas_course_id, name) VALUES
 (1, '100234', 'CSCI 3021 Internet and Web Programming'),
 (1, '100871', 'MATH 2310 Linear Algebra');

INSERT INTO notes (course_id, title, body) VALUES
 (1, 'Servlet lifecycle', 'init() runs once, service() per request (doGet/doPost), destroy() on shutdown. Servlets are multi-threaded, so avoid shared mutable fields.'),
 (1, 'Sessions', 'HttpSession tracks a user across requests via the JSESSIONID cookie. Call invalidate() on logout.'),
 (1, 'JDBC basics', 'Use PreparedStatement to prevent SQL injection. Always close ResultSet, Statement, Connection in finally.'),
 (2, 'Eigenvalues', 'Av = lambda v. Solve det(A - lambda I) = 0. I am still confused about repeated eigenvalues.'),
 (2, 'Matrix rank', 'Rank = number of pivot columns after row reduction.');

INSERT INTO canvas_items (course_id, type, title, due_date, body) VALUES
 (1, 'assignment', 'Project Milestone: Backend and Agent', '2026-11-13', 'Servlets, DB, first LLM tool call.'),
 (1, 'module',     'Module 8: JDBC and Databases', NULL, 'Connections, PreparedStatement, transactions.'),
 (1, 'quiz',       'Quiz 3: Servlets and Sessions', '2026-10-20', NULL),
 (1, 'quiz',       'Quiz 4: JDBC', '2026-11-03', NULL),
 (2, 'assignment', 'Homework 9: Eigenvalues', '2026-11-16', 'Problems 1-12.'),
 (2, 'quiz',       'Quiz 5: Determinants and Eigenvalues', '2026-11-05', NULL);

INSERT INTO quiz_results (item_id, topic, score, max_score) VALUES
 (3, 'Session tracking',   4, 5),
 (3, 'Servlet lifecycle',  5, 5),
 (3, 'Cookies',            2, 5),
 (4, 'PreparedStatement',  3, 5),
 (4, 'Transactions',       1, 5),
 (6, 'Determinants',       5, 5),
 (6, 'Eigenvalues',        2, 5);

INSERT INTO study_plans (course_id, plan_text) VALUES
 (1, 'Sample plan: review cookies and transactions before the final.');

INSERT INTO agent_log (user_id, tool_name, `input`, `output`, success) VALUES
 (1, 'get_course_notes', '{"course_id":1}', '{"note_count":3}', TRUE);

-- Optional: least-privilege DB account for the app (change the password!)
-- CREATE USER 'coursecraft_app'@'localhost' IDENTIFIED BY 'change-me';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON coursecraft.* TO 'coursecraft_app'@'localhost';
