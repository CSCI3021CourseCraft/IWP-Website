package agent;

import java.sql.*;

public class AgentLogDao {
    public static void log(int userId, String tool, String input, String output) throws SQLException {
        String sql = "INSERT INTO agent_log (user_id, tool_name, `input`, `output`) VALUES (?,?,?,?)";
        try (Connection con = Db.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setString(2, tool);
            ps.setString(3, input);
            ps.setString(4, output);
            ps.executeUpdate();
        }
    }
}