package agent;

import java.sql.*;

public class CourseDao {
    public static boolean owns(int userId, int courseId) throws SQLException {
        String sql = "SELECT 1 FROM courses WHERE id = ? AND user_id = ?";
        try (Connection con = Db.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            ps.setInt(2, userId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    /** "id=1 name=Data Structures; id=2 name=..." (given to the LLM so it knows real course ids) */
    public static String listForPrompt(int userId) throws SQLException {
        String sql = "SELECT id, name FROM courses WHERE user_id = ? ORDER BY id";
        StringBuilder sb = new StringBuilder();
        try (Connection con = Db.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) sb.append("course_id=").append(rs.getInt("id"))
                        .append(" (").append(rs.getString("name")).append("); ");
            }
        }
        return sb.length() == 0 ? "(no courses)" : sb.toString();
    }
}