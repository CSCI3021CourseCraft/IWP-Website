package agent;

import com.google.gson.*;

public class ToolDefs {
    public static JsonArray all() {
        return JsonParser.parseString("""
        [
          {"type":"function","function":{
            "name":"get_course_notes",
            "description":"Retrieve the student's notes for one course.",
            "parameters":{"type":"object",
              "properties":{"course_id":{"type":"integer","description":"ID of the course"}},
              "required":["course_id"]}}},
          {"type":"function","function":{
            "name":"get_quiz_results",
            "description":"Retrieve quiz performance per topic for a course, weakest topics first.",
            "parameters":{"type":"object",
              "properties":{"course_id":{"type":"integer","description":"ID of the course"}},
              "required":["course_id"]}}},
          {"type":"function","function":{
            "name":"save_study_plan",
            "description":"Save a finished study plan for a course.",
            "parameters":{"type":"object",
              "properties":{
                "course_id":{"type":"integer","description":"ID of the course"},
                "plan_text":{"type":"string","description":"The full study plan text"}},
              "required":["course_id","plan_text"]}}}
        ]
        """).getAsJsonArray();
    }
}