package agent;

import com.google.gson.*;
import java.sql.*;

public class NoteDao {
    public static JsonArray byCourse(int courseId) throws SQLException {
        String sql = "SELECT id, title, body, updated_at FROM notes WHERE course_id = ? ORDER BY updated_at DESC";
        JsonArray arr = new JsonArray();
        try (Connection con = Db.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    JsonObject o = new JsonObject();
                    o.addProperty("id", rs.getInt("id"));
                    o.addProperty("title", rs.getString("title"));
                    o.addProperty("body", rs.getString("body"));
                    o.addProperty("updated_at", rs.getTimestamp("updated_at").toString());
                    arr.add(o);
                }
            }
        }
        return arr;
    }
}