package agent;

import com.google.gson.JsonObject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/tools/get_course_notes")
public class NotesToolServlet extends ToolServletBase {
    @Override protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        process(req, resp);
    }
    @Override protected JsonObject handle(int userId, HttpServletRequest req) throws Exception {
        return ToolService.getCourseNotes(userId, intParam(req, "course_id"));
    }
}