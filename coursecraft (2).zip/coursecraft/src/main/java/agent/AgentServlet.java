package agent;

import java.io.IOException;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/agent")
public class AgentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        JsonObject out = new JsonObject();

        try {
            // 1. Session check
            Integer userId = Auth.userId(req);
            if (userId == null) {
                resp.setStatus(401);
                out.addProperty("success", false);
                out.addProperty("error", "Not logged in");
                resp.getWriter().print(out);
                return;
            }

            // 2. Validate input
            String goal = req.getParameter("goal");
            if (goal == null || goal.isBlank() || goal.length() > 1000) {
                resp.setStatus(400);
                out.addProperty("success", false);
                out.addProperty("error", "Goal must be 1-1000 characters");
                resp.getWriter().print(out);
                return;
            }

            // 3. PLAN: send goal + tool definitions to the LLM
            String system = "You are a study assistant for a college student. "
                    + "The student's courses are: " + CourseDao.listForPrompt(userId) + " "
                    + "When the student asks about their notes, quiz results, or a study plan, call the "
                    + "appropriate tool with the correct course_id. Do not guess ids.";
            JsonArray messages = new JsonArray();
            messages.add(msg("system", system));
            messages.add(msg("user", goal));

            JsonObject llm = GroqClient.chat(messages, ToolDefs.all());
            JsonObject message = llm.getAsJsonArray("choices").get(0)
                    .getAsJsonObject().getAsJsonObject("message");

            // The model may reply in plain text without calling a tool
            if (!message.has("tool_calls") || message.get("tool_calls").isJsonNull()) {
                out.addProperty("success", true);
                out.addProperty("toolCalled", false);
                String content = message.has("content") && !message.get("content").isJsonNull()
                        ? message.get("content").getAsString() : "";
                out.addProperty("answer", content);
                resp.getWriter().print(out);
                return;
            }

            // 4. ACT: execute the first tool call
            JsonObject fn = message.getAsJsonArray("tool_calls").get(0)
                    .getAsJsonObject().getAsJsonObject("function");
            String toolName = fn.get("name").getAsString();
            JsonObject args;
            try {
                args = JsonParser.parseString(fn.get("arguments").getAsString()).getAsJsonObject();
            } catch (Exception e) {
                args = new JsonObject();   // malformed args: tool will report a validation error
            }

            JsonObject result;
            try {
                result = ToolService.dispatch(userId, toolName, args);
            } catch (IllegalArgumentException | SecurityException e) {
                result = new JsonObject();                 // tool failures are observations too
                result.addProperty("success", false);
                result.addProperty("error", e.getMessage());
            }

            // 5. OBSERVE: log it and return it
            AgentLogDao.log(userId, toolName, args.toString(), result.toString());

            out.addProperty("success", true);
            out.addProperty("toolCalled", true);
            out.addProperty("tool", toolName);
            out.add("arguments", args);
            out.add("result", result);
            resp.getWriter().print(out);

        } catch (Exception e) {
            getServletContext().log("Agent error", e);
            resp.setStatus(500);
            out = new JsonObject();
            out.addProperty("success", false);
            out.addProperty("error", e.getMessage());
            resp.getWriter().print(out);
        }
    }

    private static JsonObject msg(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }
}