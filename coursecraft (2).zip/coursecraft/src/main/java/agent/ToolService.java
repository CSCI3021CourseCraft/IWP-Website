package agent;

import com.google.gson.*;
import java.sql.SQLException;

public class ToolService {

    public static JsonObject getCourseNotes(int userId, int courseId) throws SQLException {
        requireOwner(userId, courseId);
        JsonObject o = ok();
        o.add("notes", NoteDao.byCourse(courseId));
        return o;
    }

    public static JsonObject getQuizResults(int userId, int courseId) throws SQLException {
        requireOwner(userId, courseId);
        JsonObject o = ok();
        o.add("topics", QuizDao.byCourse(courseId));
        return o;
    }

    public static JsonObject saveStudyPlan(int userId, int courseId, String planText) throws SQLException {
        if (planText == null || planText.isBlank() || planText.length() > 10000)
            throw new IllegalArgumentException("plan_text must be 1-10000 characters");
        requireOwner(userId, courseId);
        int id = PlanDao.save(courseId, planText.trim());
        JsonObject o = ok();
        o.addProperty("plan_id", id);
        return o;
    }

    /** Used by the agent: userId always comes from the session, never from the model. */
    public static JsonObject dispatch(int userId, String tool, JsonObject args) throws SQLException {
        switch (tool) {
            case "get_course_notes":  return getCourseNotes(userId, intArg(args, "course_id"));
            case "get_quiz_results":  return getQuizResults(userId, intArg(args, "course_id"));
            case "save_study_plan":
                return saveStudyPlan(userId, intArg(args, "course_id"), strArg(args, "plan_text"));
            default: throw new IllegalArgumentException("Unknown tool: " + tool);
        }
    }

    // ---- helpers ----
    private static void requireOwner(int userId, int courseId) throws SQLException {
        if (!CourseDao.owns(userId, courseId))
            throw new SecurityException("Course not found or not yours");
    }
    private static JsonObject ok() { JsonObject o = new JsonObject(); o.addProperty("success", true); return o; }

    public static int intArg(JsonObject a, String k) {
        try { return a.get(k).getAsInt(); }
        catch (Exception e) { throw new IllegalArgumentException("Missing or invalid " + k); }
    }
    public static String strArg(JsonObject a, String k) {
        try { return a.get(k).getAsString(); }
        catch (Exception e) { throw new IllegalArgumentException("Missing or invalid " + k); }
    }
}