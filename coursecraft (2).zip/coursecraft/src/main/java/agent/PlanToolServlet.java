package agent;

import com.google.gson.JsonObject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/tools/save_study_plan")
public class PlanToolServlet extends ToolServletBase {
    @Override protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        process(req, resp);
    }
    @Override protected JsonObject handle(int userId, HttpServletRequest req) throws Exception {
        return ToolService.saveStudyPlan(userId, intParam(req, "course_id"), req.getParameter("plan_text"));
    }
}