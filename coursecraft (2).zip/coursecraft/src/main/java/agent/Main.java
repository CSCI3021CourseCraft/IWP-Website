package agent;

import com.google.gson.*;

public class Main {
    public static void main(String[] args) throws Exception {
        String goal = args.length > 0 ? String.join(" ", args) : "Show me my notes for course 1";

        JsonArray messages = new JsonArray();
        messages.add(msg("system", "You are a study assistant. Student's courses: "
                + "course_id=1 (Data Structures); course_id=2 (Internet and Web Programming). "
                + "Call the right tool with the correct course_id."));
        messages.add(msg("user", goal));

        JsonObject resp = GroqClient.chat(messages, ToolDefs.all());
        JsonObject message = resp.getAsJsonArray("choices").get(0)
                .getAsJsonObject().getAsJsonObject("message");

        System.out.println(new GsonBuilder().setPrettyPrinting().create().toJson(message));
    }

    private static JsonObject msg(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }
}