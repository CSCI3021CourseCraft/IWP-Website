package agent;

import jakarta.servlet.http.*;

public class Auth {
    /** Returns the logged-in user's id, or null if not logged in. */
    public static Integer userId(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s == null) return null;
        Object id = s.getAttribute("userId");
        return (id instanceof Integer) ? (Integer) id : null;
    }
}
