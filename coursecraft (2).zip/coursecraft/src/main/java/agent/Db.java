package agent;

import java.sql.*;

public class Db {
    static {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }
        catch (ClassNotFoundException e) { throw new RuntimeException(e); }
    }

    private static String env(String k, String def) {
        String v = System.getenv(k);
        return (v == null || v.isBlank()) ? def : v;
    }

    public static Connection getConnection() throws SQLException {
        String url  = env("DB_URL", "jdbc:mysql://localhost:3306/coursecraft?useSSL=false&allowPublicKeyRetrieval=true");
        String user = env("DB_USER", "root");
        String pass = env("DB_PASSWORD", "");          // password comes from the environment only
        return DriverManager.getConnection(url, user, pass);
    }
}
