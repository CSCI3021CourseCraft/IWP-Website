package agent;

import com.google.gson.JsonObject;
import jakarta.servlet.http.*;
import java.io.IOException;

public abstract class ToolServletBase extends HttpServlet {

    protected abstract JsonObject handle(int userId, HttpServletRequest req) throws Exception;

    protected void process(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        JsonObject out;
        Integer userId = Auth.userId(req);
        if (userId == null) {
            resp.setStatus(401);
            out = error("Not logged in");
        } else {
            try {
                out = handle(userId, req);
            } catch (IllegalArgumentException e) {
                resp.setStatus(400);
                out = error(e.getMessage());
            } catch (SecurityException e) {
                resp.setStatus(403);
                out = error(e.getMessage());
            } catch (Exception e) {
                getServletContext().log("Tool error", e);
                resp.setStatus(500);
                out = error("Server error");
            }
        }
        resp.getWriter().print(out);
    }

    protected static JsonObject error(String msg) {
        JsonObject o = new JsonObject();
        o.addProperty("success", false);
        o.addProperty("error", msg);
        return o;
    }

    protected static int intParam(HttpServletRequest req, String name) {
        try { return Integer.parseInt(req.getParameter(name)); }
        catch (Exception e) { throw new IllegalArgumentException("Missing or invalid " + name); }
    }
}