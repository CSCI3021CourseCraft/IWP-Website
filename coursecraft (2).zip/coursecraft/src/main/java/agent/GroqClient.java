package agent;
import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;

public class GroqClient {
    private static final String URL = "https://api.groq.com/openai/v1/chat/completions";
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10)).build();

    public static JsonObject chat(JsonArray messages, JsonArray tools) throws Exception {
        String key = System.getenv("GROQ_API_KEY");
        if (key == null || key.isBlank()) throw new IllegalStateException("GROQ_API_KEY is not set");
        String model = System.getenv("GROQ_MODEL");
        if (model == null || model.isBlank()) model = "llama-3.3-70b-versatile";

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.add("tools", tools);
        body.addProperty("tool_choice", "auto");
        body.addProperty("temperature", 0.2);

        HttpRequest req = HttpRequest.newBuilder(URI.create(URL))
                .timeout(Duration.ofSeconds(30))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + key)
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();

        HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() == 429) throw new RuntimeException("LLM rate limit hit. Wait a minute and retry.");
        if (resp.statusCode() != 200) throw new RuntimeException("LLM error " + resp.statusCode() + ": " + resp.body());
        return JsonParser.parseString(resp.body()).getAsJsonObject();
    }
}

//Make sure to set the GROQ_API_KEY environment variable to your Groq API key before using this client.