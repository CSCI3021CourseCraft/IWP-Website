package agent;

import com.google.gson.*;
import java.sql.*;

public class QuizDao {
    /** Average percentage per topic, weakest first. */
    public static JsonArray byCourse(int courseId) throws SQLException {
        String sql = "SELECT topic, COUNT(*) AS attempts, SUM(score) AS s, SUM(max_score) AS m "
                   + "FROM quiz_results WHERE course_id = ? GROUP BY topic ORDER BY (SUM(score)/SUM(max_score)) ASC";
        JsonArray arr = new JsonArray();
        try (Connection con = Db.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    JsonObject o = new JsonObject();
                    o.addProperty("topic", rs.getString("topic"));
                    o.addProperty("attempts", rs.getInt("attempts"));
                    o.addProperty("percent", Math.round(100.0 * rs.getInt("s") / rs.getInt("m")));
                    arr.add(o);
                }
            }
        }
        return arr;
    }
}