package agent;

import java.sql.*;

public class PlanDao {
    public static int save(int courseId, String planText) throws SQLException {
        String sql = "INSERT INTO study_plans (course_id, plan_text) VALUES (?, ?)";
        try (Connection con = Db.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, courseId);
            ps.setString(2, planText);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
                throw new SQLException("No plan id returned");
            }
        }
    }
}