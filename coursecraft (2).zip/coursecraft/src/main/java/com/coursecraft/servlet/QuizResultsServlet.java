package com.coursecraft.servlet;

import com.coursecraft.service.ToolService;
import com.coursecraft.service.ToolService.ToolException;
import com.coursecraft.util.Http;
import com.google.gson.JsonObject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/** Tool get_quiz_results:  GET /api/tools/quiz-results?course_id=1 */
@WebServlet("/api/tools/quiz-results")
public class QuizResultsServlet extends ToolServlet {
    @Override
    protected String toolName() {
        return ToolService.GET_QUIZ_RESULTS;
    }

    @Override
    protected JsonObject buildInput(HttpServletRequest req) throws ToolException {
        JsonObject in = new JsonObject();
        in.addProperty("course_id", Http.requireLongParam(req, "course_id"));
        return in;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        handle(req, resp);
    }
}
