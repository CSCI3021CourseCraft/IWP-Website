package com.coursecraft.servlet;

import com.coursecraft.service.ToolService;
import com.coursecraft.service.ToolService.ToolException;
import com.coursecraft.util.Db;
import com.coursecraft.util.Http;
import com.google.gson.JsonObject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** POST /api/notes (form: course_id, title, body) creates a note: Form -> Servlet -> Database. */
@WebServlet("/api/notes")
public class NoteServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long uid = Http.requireUser(req, resp);
        if (uid == null) {
            return;
        }
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet keys = null;
        try {
            long courseId = Http.requireLongParam(req, "course_id");
            String title = req.getParameter("title") == null ? "" : req.getParameter("title").trim();
            String body = req.getParameter("body") == null ? "" : req.getParameter("body").trim();
            if (title.isEmpty() || title.length() > 200) {
                throw new ToolException(400, "Title is required (max 200 characters)");
            }
            if (body.isEmpty() || body.length() > 20000) {
                throw new ToolException(400, "Body is required (max 20000 characters)");
            }
            conn = Db.getConnection();
            ToolService.requireOwnedCourse(conn, uid, courseId);
            ps = conn.prepareStatement("INSERT INTO notes (course_id, title, body) VALUES (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setLong(1, courseId);
            ps.setString(2, title);
            ps.setString(3, body);
            ps.executeUpdate();
            keys = ps.getGeneratedKeys();
            JsonObject out = new JsonObject();
            if (keys.next()) {
                out.addProperty("note_id", keys.getLong(1));
            }
            Http.ok(resp, out);
        } catch (ToolException e) {
            Http.error(resp, e.getStatus(), e.getMessage());
        } catch (SQLException e) {
            System.err.println("Create note failed: " + e);
            Http.error(resp, 500, "Database error");
        } finally {
            Db.close(keys, ps, conn);
        }
    }
}
