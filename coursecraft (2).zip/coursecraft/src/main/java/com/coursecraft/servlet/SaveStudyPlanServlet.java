package com.coursecraft.servlet;

import com.coursecraft.service.ToolService;
import com.coursecraft.service.ToolService.ToolException;
import com.coursecraft.util.Http;
import com.google.gson.JsonObject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/** Tool save_study_plan (changes state):  POST /api/tools/save-study-plan  (form or JSON: course_id, plan_text) */
@WebServlet("/api/tools/save-study-plan")
public class SaveStudyPlanServlet extends ToolServlet {
    @Override
    protected String toolName() {
        return ToolService.SAVE_STUDY_PLAN;
    }

    @Override
    protected JsonObject buildInput(HttpServletRequest req) throws ToolException, IOException {
        if (Http.isJson(req)) {
            return Http.readJson(req);
        }
        JsonObject in = new JsonObject();
        in.addProperty("course_id", Http.requireLongParam(req, "course_id"));
        in.addProperty("plan_text", req.getParameter("plan_text") == null ? "" : req.getParameter("plan_text"));
        return in;
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        handle(req, resp);
    }
}
