package com.coursecraft.servlet;

import com.coursecraft.util.Db;
import com.coursecraft.util.Http;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** GET /api/courses lists the user's courses; POST creates one (form: name). */
@WebServlet("/api/courses")
public class CourseServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long uid = Http.requireUser(req, resp);
        if (uid == null) {
            return;
        }
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement("SELECT id, name FROM courses WHERE user_id = ? ORDER BY name");
            ps.setLong(1, uid);
            rs = ps.executeQuery();
            JsonArray arr = new JsonArray();
            while (rs.next()) {
                JsonObject c = new JsonObject();
                c.addProperty("id", rs.getLong("id"));
                c.addProperty("name", rs.getString("name"));
                arr.add(c);
            }
            JsonObject out = new JsonObject();
            out.add("courses", arr);
            Http.ok(resp, out);
        } catch (SQLException e) {
            System.err.println("List courses failed: " + e);
            Http.error(resp, 500, "Database error");
        } finally {
            Db.close(rs, ps, conn);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long uid = Http.requireUser(req, resp);
        if (uid == null) {
            return;
        }
        String name = req.getParameter("name") == null ? "" : req.getParameter("name").trim();
        if (name.isEmpty() || name.length() > 200) {
            Http.error(resp, 400, "Course name is required (max 200 characters)");
            return;
        }
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet keys = null;
        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement("INSERT INTO courses (user_id, name) VALUES (?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setLong(1, uid);
            ps.setString(2, name);
            ps.executeUpdate();
            keys = ps.getGeneratedKeys();
            JsonObject out = new JsonObject();
            if (keys.next()) {
                out.addProperty("course_id", keys.getLong(1));
            }
            Http.ok(resp, out);
        } catch (SQLException e) {
            System.err.println("Create course failed: " + e);
            Http.error(resp, 500, "Database error");
        } finally {
            Db.close(keys, ps, conn);
        }
    }
}
