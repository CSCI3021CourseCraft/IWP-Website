package com.coursecraft.servlet;

import com.coursecraft.util.Db;
import com.coursecraft.util.Http;
import com.coursecraft.util.Passwords;
import com.google.gson.JsonObject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Pattern;

/** POST /api/auth  action=register|login|logout   GET /api/auth = who am I. */
@WebServlet("/api/auth")
public class AuthServlet extends HttpServlet {
    private static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long uid = Http.requireUser(req, resp);
        if (uid == null) {
            return;
        }
        JsonObject o = new JsonObject();
        o.addProperty("user_id", uid);
        o.addProperty("email", String.valueOf(req.getSession(false).getAttribute("email")));
        Http.ok(resp, o);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String action = req.getParameter("action");
        if ("logout".equals(action)) {
            HttpSession s = req.getSession(false);
            if (s != null) {
                s.invalidate();
            }
            Http.ok(resp, new JsonObject());
            return;
        }
        String email = req.getParameter("email") == null ? "" : req.getParameter("email").trim().toLowerCase();
        String password = req.getParameter("password") == null ? "" : req.getParameter("password");
        if (!EMAIL.matcher(email).matches() || email.length() > 255) {
            Http.error(resp, 400, "Enter a valid email address");
            return;
        }
        if (password.length() < 8 || password.length() > 200) {
            Http.error(resp, 400, "Password must be 8 to 200 characters");
            return;
        }
        if ("register".equals(action)) {
            register(req, resp, email, password);
        } else if ("login".equals(action)) {
            login(req, resp, email, password);
        } else {
            Http.error(resp, 400, "action must be register, login or logout");
        }
    }

    private void register(HttpServletRequest req, HttpServletResponse resp, String email, String password)
            throws IOException {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement("INSERT INTO users (email, password_hash) VALUES (?, ?)");
            ps.setString(1, email);
            ps.setString(2, Passwords.hash(password));
            ps.executeUpdate();
            login(req, resp, email, password);
        } catch (SQLException e) {
            if ("23505".equals(e.getSQLState())) {
                Http.error(resp, 409, "That email is already registered");
            } else {
                System.err.println("Register failed: " + e);
                Http.error(resp, 500, "Database error");
            }
        } finally {
            Db.close(ps, conn);
        }
    }

    private void login(HttpServletRequest req, HttpServletResponse resp, String email, String password)
            throws IOException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement("SELECT id, password_hash FROM users WHERE email = ?");
            ps.setString(1, email);
            rs = ps.executeQuery();
            if (!rs.next() || !Passwords.verify(password, rs.getString("password_hash"))) {
                Http.error(resp, 401, "Wrong email or password");
                return;
            }
            HttpSession old = req.getSession(false);
            if (old != null) {
                old.invalidate(); // new session id on login (prevents session fixation)
            }
            HttpSession s = req.getSession(true);
            s.setAttribute(Http.SESSION_USER, rs.getLong("id"));
            s.setAttribute("email", email);
            JsonObject o = new JsonObject();
            o.addProperty("user_id", rs.getLong("id"));
            o.addProperty("email", email);
            Http.ok(resp, o);
        } catch (SQLException e) {
            System.err.println("Login failed: " + e);
            Http.error(resp, 500, "Database error");
        } finally {
            Db.close(rs, ps, conn);
        }
    }
}
