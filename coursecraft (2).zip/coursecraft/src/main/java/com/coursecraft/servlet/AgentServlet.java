package com.coursecraft.servlet;

import com.coursecraft.llm.AgentTools;
import com.coursecraft.llm.ClaudeClient;
import com.coursecraft.service.ToolService;
import com.coursecraft.service.ToolService.ToolException;
import com.coursecraft.util.Config;
import com.coursecraft.util.Http;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * POST /api/agent  (form or JSON: goal, course_id)
 * plan (LLM picks a tool) -> act (ToolService runs it as the logged-in user, logged to agent_log)
 * -> observe (result returned). AGENT_MAX_STEPS=1 gives exactly one cycle (milestone);
 * set it higher (e.g. 8) for the full re-planning loop (bonus).
 */
@WebServlet("/api/agent")
public class AgentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long uid = Http.requireUser(req, resp);
        if (uid == null) {
            return;
        }
        try {
            String goal;
            long courseId;
            if (Http.isJson(req)) {
                JsonObject in = Http.readJson(req);
                goal = in.has("goal") ? in.get("goal").getAsString() : "";
                courseId = in.has("course_id") ? in.get("course_id").getAsLong() : -1;
            } else {
                goal = req.getParameter("goal") == null ? "" : req.getParameter("goal");
                courseId = Http.requireLongParam(req, "course_id");
            }
            goal = goal.trim();
            if (goal.length() < 3 || goal.length() > 2000) {
                throw new ToolException(400, "goal must be 3 to 2000 characters");
            }
            if (courseId <= 0) {
                throw new ToolException(400, "course_id is required");
            }
            ToolService.requireOwnedCourse(uid, courseId);
            if (!ClaudeClient.hasApiKey()) {
                throw new ToolException(500, "ANTHROPIC_API_KEY is not configured on the server");
            }
            runAgent(uid, goal, courseId, resp);
        } catch (ToolException e) {
            Http.error(resp, e.getStatus(), e.getMessage());
        } catch (RuntimeException e) {
            Http.error(resp, 400, "Invalid request");
        }
    }

    private void runAgent(long uid, String goal, long courseId, HttpServletResponse resp) throws IOException {
        int maxSteps = 1;
        try {
            maxSteps = Math.max(1, Math.min(8, Integer.parseInt(Config.get("AGENT_MAX_STEPS", "1"))));
        } catch (NumberFormatException ignored) {
            // keep default
        }
        String system = "You are CourseCraft's study assistant. The student is working on course_id "
                + courseId + ". Use the tools to read their notes and quiz results, identify weak topics, "
                + "then write a short study plan and save it with save_study_plan. "
                + "Only use course_id " + courseId + ".";

        JsonArray messages = new JsonArray();
        messages.add(message("user", new com.google.gson.JsonPrimitive(goal)));
        JsonArray steps = new JsonArray();
        String finalAnswer = null;
        ClaudeClient claude = new ClaudeClient();

        try {
            for (int step = 1; step <= maxSteps; step++) {
                JsonObject reply = claude.createMessage(system, messages, AgentTools.definitions());
                JsonArray content = reply.getAsJsonArray("content");
                StringBuilder text = new StringBuilder();
                JsonArray toolUses = new JsonArray();
                for (JsonElement el : content) {
                    JsonObject block = el.getAsJsonObject();
                    String type = block.get("type").getAsString();
                    if ("text".equals(type)) {
                        text.append(block.get("text").getAsString());
                    } else if ("tool_use".equals(type)) {
                        toolUses.add(block);
                    }
                }
                if (toolUses.size() == 0) {
                    finalAnswer = text.toString();
                    break;
                }
                messages.add(message("assistant", content));
                JsonArray toolResults = new JsonArray();
                for (JsonElement el : toolUses) {
                    JsonObject tu = el.getAsJsonObject();
                    String name = tu.get("name").getAsString();
                    JsonObject input = tu.getAsJsonObject("input");
                    JsonObject observation;
                    boolean isError = false;
                    try {
                        observation = ToolService.execute(uid, name, input); // logs to agent_log
                    } catch (ToolException e) {
                        observation = new JsonObject();
                        observation.addProperty("error", e.getMessage());
                        isError = true;
                    }
                    JsonObject s = new JsonObject();
                    s.addProperty("step", step);
                    s.addProperty("tool", name);
                    s.add("input", input);
                    s.add("observation", observation);
                    s.addProperty("is_error", isError);
                    steps.add(s);

                    JsonObject tr = new JsonObject();
                    tr.addProperty("type", "tool_result");
                    tr.addProperty("tool_use_id", tu.get("id").getAsString());
                    tr.addProperty("content", observation.toString());
                    tr.addProperty("is_error", isError);
                    toolResults.add(tr);
                }
                messages.add(message("user", toolResults));
            }
        } catch (IOException e) {
            System.err.println("LLM call failed: " + e.getMessage());
            Http.error(resp, 502, "The LLM request failed. Check ANTHROPIC_API_KEY and the server log.");
            return;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            Http.error(resp, 500, "Interrupted");
            return;
        }

        JsonObject out = new JsonObject();
        out.addProperty("goal", goal);
        out.addProperty("max_steps", maxSteps);
        out.add("steps", steps);
        if (finalAnswer != null) {
            out.addProperty("final_answer", finalAnswer);
        }
        out.addProperty("stopped", finalAnswer != null ? "completed" : "step_limit");
        Http.ok(resp, out);
    }

    private static JsonObject message(String role, JsonElement content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.add("content", content);
        return m;
    }
}
