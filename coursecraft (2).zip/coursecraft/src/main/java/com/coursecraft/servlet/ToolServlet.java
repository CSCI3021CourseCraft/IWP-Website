package com.coursecraft.servlet;

import com.coursecraft.service.ToolService;
import com.coursecraft.service.ToolService.ToolException;
import com.coursecraft.util.Http;
import com.google.gson.JsonObject;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/** Base class: session check -> build input -> ToolService.execute -> JSON response. */
public abstract class ToolServlet extends HttpServlet {

    protected abstract String toolName();

    protected abstract JsonObject buildInput(HttpServletRequest req) throws ToolException, IOException;

    protected final void handle(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Long uid = Http.requireUser(req, resp);
        if (uid == null) {
            return; // 401 already sent
        }
        try {
            JsonObject input = buildInput(req);
            JsonObject result = ToolService.execute(uid, toolName(), input);
            JsonObject out = new JsonObject();
            out.addProperty("tool", toolName());
            out.add("result", result);
            Http.ok(resp, out);
        } catch (ToolException e) {
            Http.error(resp, e.getStatus(), e.getMessage());
        }
    }
}
