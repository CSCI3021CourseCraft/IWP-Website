package com.coursecraft.service;

import com.coursecraft.util.Db;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * The three agent tools. Both the REST servlets and the AgentServlet call
 * execute(), so the agent has exactly the same validation, authorization and
 * logging as a normal user request. The userId always comes from the session,
 * never from the request or the model.
 */
public final class ToolService {

    public static final String GET_COURSE_NOTES = "get_course_notes";
    public static final String GET_QUIZ_RESULTS = "get_quiz_results";
    public static final String SAVE_STUDY_PLAN = "save_study_plan";

    private static final int MAX_PLAN_CHARS = 20000;

    public static class ToolException extends Exception {
        private final int status;

        public ToolException(int status, String message) {
            super(message);
            this.status = status;
        }

        public int getStatus() {
            return status;
        }
    }

    private ToolService() { }

    /** Validates, runs the tool, and logs the call (success or failure). */
    public static JsonObject execute(long userId, String tool, JsonObject input) throws ToolException {
        JsonObject result = null;
        String errorMessage = null;
        try {
            if (tool == null) {
                throw new ToolException(400, "Missing tool name");
            }
            switch (tool) {
                case GET_COURSE_NOTES:
                    result = getCourseNotes(userId, input);
                    break;
                case GET_QUIZ_RESULTS:
                    result = getQuizResults(userId, input);
                    break;
                case SAVE_STUDY_PLAN:
                    result = saveStudyPlan(userId, input);
                    break;
                default:
                    throw new ToolException(400, "Unknown tool: " + tool);
            }
            return result;
        } catch (ToolException e) {
            errorMessage = e.getMessage();
            throw e;
        } catch (SQLException e) {
            System.err.println("DB error in tool " + tool + ": " + e);
            errorMessage = "Database error";
            throw new ToolException(500, errorMessage);
        } finally {
            JsonObject out = result;
            if (out == null) {
                out = new JsonObject();
                out.addProperty("error", errorMessage == null ? "Unknown error" : errorMessage);
            }
            AgentLogDao.log(userId, tool == null ? "(none)" : tool,
                    input == null ? "{}" : input.toString(), out.toString(), result != null);
        }
    }

    // ---------------------------------------------------------------- tools

    private static JsonObject getCourseNotes(long userId, JsonObject input) throws ToolException, SQLException {
        long courseId = requireCourseId(input);
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = Db.getConnection();
            requireOwnedCourse(conn, userId, courseId);
            ps = conn.prepareStatement(
                    "SELECT id, title, body, updated_at FROM notes WHERE course_id = ? ORDER BY updated_at DESC LIMIT 50");
            ps.setLong(1, courseId);
            rs = ps.executeQuery();
            JsonArray notes = new JsonArray();
            while (rs.next()) {
                JsonObject n = new JsonObject();
                n.addProperty("id", rs.getLong("id"));
                n.addProperty("title", rs.getString("title"));
                n.addProperty("body", rs.getString("body"));
                n.addProperty("updated_at", String.valueOf(rs.getTimestamp("updated_at")));
                notes.add(n);
            }
            JsonObject out = new JsonObject();
            out.addProperty("course_id", courseId);
            out.addProperty("note_count", notes.size());
            out.add("notes", notes);
            return out;
        } finally {
            Db.close(rs, ps, conn);
        }
    }

    private static JsonObject getQuizResults(long userId, JsonObject input) throws ToolException, SQLException {
        long courseId = requireCourseId(input);
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = Db.getConnection();
            requireOwnedCourse(conn, userId, courseId);
            ps = conn.prepareStatement(
                    "SELECT ci.title AS quiz_title, ci.due_date, q.topic, q.score, q.max_score "
                    + "FROM quiz_results q JOIN canvas_items ci ON q.item_id = ci.id "
                    + "WHERE ci.course_id = ? ORDER BY ci.due_date, q.topic");
            ps.setLong(1, courseId);
            rs = ps.executeQuery();
            JsonArray results = new JsonArray();
            while (rs.next()) {
                double score = rs.getDouble("score");
                double max = rs.getDouble("max_score");
                JsonObject r = new JsonObject();
                r.addProperty("quiz", rs.getString("quiz_title"));
                r.addProperty("topic", rs.getString("topic"));
                r.addProperty("score", score);
                r.addProperty("max_score", max);
                double pct = max > 0 ? Math.round(1000.0 * score / max) / 10.0 : 0;
                r.addProperty("percent", pct);
                r.addProperty("weak", pct < 70.0);
                results.add(r);
            }
            JsonObject out = new JsonObject();
            out.addProperty("course_id", courseId);
            out.add("results", results);
            return out;
        } finally {
            Db.close(rs, ps, conn);
        }
    }

    /** State-changing tool: inserts a study plan row. */
    private static JsonObject saveStudyPlan(long userId, JsonObject input) throws ToolException, SQLException {
        long courseId = requireCourseId(input);
        String plan = (input.has("plan_text") && input.get("plan_text").isJsonPrimitive())
                ? input.get("plan_text").getAsString().trim() : "";
        if (plan.isEmpty()) {
            throw new ToolException(400, "plan_text is required");
        }
        if (plan.length() > MAX_PLAN_CHARS) {
            throw new ToolException(400, "plan_text must be at most " + MAX_PLAN_CHARS + " characters");
        }
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet keys = null;
        try {
            conn = Db.getConnection();
            requireOwnedCourse(conn, userId, courseId);
            ps = conn.prepareStatement(
                    "INSERT INTO study_plans (course_id, plan_text) VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS);
            ps.setLong(1, courseId);
            ps.setString(2, plan);
            ps.executeUpdate();
            keys = ps.getGeneratedKeys();
            JsonObject out = new JsonObject();
            out.addProperty("course_id", courseId);
            if (keys.next()) {
                out.addProperty("plan_id", keys.getLong(1));
            }
            out.addProperty("saved", true);
            return out;
        } finally {
            Db.close(keys, ps, conn);
        }
    }

    // -------------------------------------------------------------- helpers

    private static long requireCourseId(JsonObject input) throws ToolException {
        if (input == null || !input.has("course_id") || !input.get("course_id").isJsonPrimitive()) {
            throw new ToolException(400, "course_id is required");
        }
        long id;
        try {
            id = input.get("course_id").getAsLong();
        } catch (NumberFormatException e) {
            throw new ToolException(400, "course_id must be an integer");
        }
        if (id <= 0) {
            throw new ToolException(400, "course_id must be positive");
        }
        return id;
    }

    /** Throws 404 unless the course belongs to the user (no hint whether it exists for someone else). */
    public static void requireOwnedCourse(Connection conn, long userId, long courseId)
            throws ToolException, SQLException {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement("SELECT 1 FROM courses WHERE id = ? AND user_id = ?");
            ps.setLong(1, courseId);
            ps.setLong(2, userId);
            rs = ps.executeQuery();
            if (!rs.next()) {
                throw new ToolException(404, "Course not found");
            }
        } finally {
            Db.close(rs, ps);
        }
    }

    public static void requireOwnedCourse(long userId, long courseId) throws ToolException {
        Connection conn = null;
        try {
            conn = Db.getConnection();
            requireOwnedCourse(conn, userId, courseId);
        } catch (SQLException e) {
            System.err.println("DB error checking course: " + e);
            throw new ToolException(500, "Database error");
        } finally {
            Db.close(conn);
        }
    }
}
