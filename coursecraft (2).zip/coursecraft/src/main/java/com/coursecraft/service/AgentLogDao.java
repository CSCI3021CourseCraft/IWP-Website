package com.coursecraft.service;

import com.coursecraft.util.Db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public final class AgentLogDao {
    private static final int MAX = 60000;

    private AgentLogDao() { }

    /** Writes one agent_log row. A logging failure never breaks the request. */
    public static void log(long userId, String tool, String input, String output, boolean success) {
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement(
                    "INSERT INTO agent_log (user_id, tool_name, input, output, success) VALUES (?, ?, ?, ?, ?)");
            ps.setLong(1, userId);
            ps.setString(2, tool);
            ps.setString(3, truncate(input));
            ps.setString(4, truncate(output));
            ps.setBoolean(5, success);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Could not write agent_log: " + e);
        } finally {
            Db.close(ps, conn);
        }
    }

    private static String truncate(String s) {
        return (s != null && s.length() > MAX) ? s.substring(0, MAX) : s;
    }
}
