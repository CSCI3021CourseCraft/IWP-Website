package com.coursecraft.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class Db {
    static {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError("PostgreSQL JDBC driver not found: " + e.getMessage());
        }
    }

    private Db() { }

    public static Connection getConnection() throws SQLException {
        String url = Config.get("DB_URL",
                "jdbc:postgresql://localhost:5432/postgres");
        return DriverManager.getConnection(url, Config.get("DB_USER", "postgres"), Config.get("DB_PASSWORD", ""));
    }

    /** Closes everything passed in, ignoring nulls and close errors. Call from finally blocks. */
    public static void close(AutoCloseable... resources) {
        for (AutoCloseable r : resources) {
            if (r != null) {
                try {
                    r.close();
                } catch (Exception ignored) {
                    // nothing useful to do
                }
            }
        }
    }
}
