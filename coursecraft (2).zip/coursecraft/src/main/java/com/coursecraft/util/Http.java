package com.coursecraft.util;

import com.coursecraft.service.ToolService.ToolException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.stream.Collectors;

/** Small helpers shared by all servlets: JSON in/out and session checks. */
public final class Http {
    public static final Gson GSON = new Gson();
    public static final String SESSION_USER = "userId";

    private Http() { }

    /** Returns the logged-in user id, or sends a 401 JSON error and returns null. */
    public static Long requireUser(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        Object id = (session == null) ? null : session.getAttribute(SESSION_USER);
        if (id instanceof Long) {
            return (Long) id;
        }
        error(resp, 401, "Not logged in");
        return null;
    }

    public static void write(HttpServletResponse resp, int status, JsonObject body) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(GSON.toJson(body));
    }

    public static void ok(HttpServletResponse resp, JsonObject body) throws IOException {
        body.addProperty("success", true);
        write(resp, 200, body);
    }

    public static void error(HttpServletResponse resp, int status, String message) throws IOException {
        JsonObject o = new JsonObject();
        o.addProperty("success", false);
        o.addProperty("error", message);
        write(resp, status, o);
    }

    public static boolean isJson(HttpServletRequest req) {
        String ct = req.getContentType();
        return ct != null && ct.toLowerCase().contains("json");
    }

    /** Reads a JSON object from the request body. */
    public static JsonObject readJson(HttpServletRequest req) throws ToolException, IOException {
        String body = req.getReader().lines().collect(Collectors.joining("\n"));
        try {
            return JsonParser.parseString(body).getAsJsonObject();
        } catch (JsonParseException | IllegalStateException e) {
            throw new ToolException(400, "Request body must be a JSON object");
        }
    }

    /** Parses a required integer request parameter. */
    public static long requireLongParam(HttpServletRequest req, String name) throws ToolException {
        String v = req.getParameter(name);
        if (v == null || v.isBlank()) {
            throw new ToolException(400, "Missing parameter: " + name);
        }
        try {
            return Long.parseLong(v.trim());
        } catch (NumberFormatException e) {
            throw new ToolException(400, "Parameter " + name + " must be an integer");
        }
    }
}
