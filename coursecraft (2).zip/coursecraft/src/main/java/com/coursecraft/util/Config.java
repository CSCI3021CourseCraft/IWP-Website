package com.coursecraft.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Reads settings from environment variables first, then from
 * src/main/resources/config.properties (which is listed in .gitignore).
 * Secrets (DB password, API key) are never hard-coded.
 */
public final class Config {
    private static final Properties FILE = new Properties();

    static {
        try (InputStream in = Config.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (in != null) {
                FILE.load(in);
            }
        } catch (IOException e) {
            System.err.println("Could not read config.properties: " + e.getMessage());
        }
    }

    private Config() { }

    public static String get(String key, String defaultValue) {
        String v = System.getenv(key);
        if (v == null || v.isBlank()) {
            v = FILE.getProperty(key);
        }
        return (v == null || v.isBlank()) ? defaultValue : v.trim();
    }
}
