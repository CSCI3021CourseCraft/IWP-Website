package com.coursecraft.llm;

import com.coursecraft.util.Config;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/** Minimal Anthropic Messages API client using java.net.http. The API key comes from Config only. */
public final class ClaudeClient {
    private static final String URL = "https://api.anthropic.com/v1/messages";
    private static final Gson GSON = new Gson();
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();

    public static boolean hasApiKey() {
        return !Config.get("ANTHROPIC_API_KEY", "").isEmpty();
    }

    public JsonObject createMessage(String system, JsonArray messages, JsonArray tools)
            throws IOException, InterruptedException {
        String key = Config.get("ANTHROPIC_API_KEY", "");
        if (key.isEmpty()) {
            throw new IOException("ANTHROPIC_API_KEY is not configured");
        }
        JsonObject body = new JsonObject();
        body.addProperty("model", Config.get("ANTHROPIC_MODEL", "claude-haiku-5-5"));
        body.addProperty("max_tokens", 1500);
        body.addProperty("system", system);
        body.add("messages", messages);
        body.add("tools", tools);

        HttpRequest request = HttpRequest.newBuilder(URI.create(URL))
                .timeout(Duration.ofSeconds(60))
                .header("content-type", "application/json")
                .header("x-api-key", key)
                .header("anthropic-version", "2023-06-01")
                .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body)))
                .build();
        HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            String snippet = response.body() == null ? "" : response.body();
            if (snippet.length() > 300) {
                snippet = snippet.substring(0, 300);
            }
            throw new IOException("LLM API returned HTTP " + response.statusCode() + ": " + snippet);
        }
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }
}
