package com.coursecraft.llm;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/** Tool definitions sent to the model (names match ToolService). */
public final class AgentTools {
    private AgentTools() { }

    public static JsonArray definitions() {
        JsonArray tools = new JsonArray();
        tools.add(tool("get_course_notes",
                "Retrieve the student's notes (title and body) for one course.",
                props(intProp("course_id", "The course id")), "course_id"));
        tools.add(tool("get_quiz_results",
                "Retrieve the student's past quiz results for a course, with percent and a weak flag per topic.",
                props(intProp("course_id", "The course id")), "course_id"));
        tools.add(tool("save_study_plan",
                "Save the finished study plan for the student. Call this once the plan is written.",
                props(intProp("course_id", "The course id"),
                      strProp("plan_text", "The full study plan text")),
                "course_id", "plan_text"));
        return tools;
    }

    private static JsonObject tool(String name, String description, JsonObject properties, String... required) {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        schema.add("properties", properties);
        JsonArray req = new JsonArray();
        for (String r : required) {
            req.add(r);
        }
        schema.add("required", req);
        JsonObject t = new JsonObject();
        t.addProperty("name", name);
        t.addProperty("description", description);
        t.add("input_schema", schema);
        return t;
    }

    private static JsonObject props(JsonObject... ps) {
        JsonObject all = new JsonObject();
        for (JsonObject p : ps) {
            String name = p.get("_name").getAsString();
            p.remove("_name");
            all.add(name, p);
        }
        return all;
    }

    private static JsonObject intProp(String name, String desc) {
        return prop(name, "integer", desc);
    }

    private static JsonObject strProp(String name, String desc) {
        return prop(name, "string", desc);
    }

    private static JsonObject prop(String name, String type, String desc) {
        JsonObject p = new JsonObject();
        p.addProperty("_name", name);
        p.addProperty("type", type);
        p.addProperty("description", desc);
        return p;
    }
}
